

<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset('img/avatar5.png')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(ucwords(Auth::user()->name)); ?></p>
          <!-- Status -->
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">
          <div class="text-center">
            <?php echo e(ucwords(auth()->user()->name)); ?>

          </div>
        </li>
        <!-- Optionally, you can add icons to the links -->
        
        <?php if(auth()->user()->type == 'admin'): ?>
        <li><a href="<?php echo e(url('/admin/users')); ?>"><i class="fa fa-home"></i> <span>Home</span></a></li>
        
        
        
        <?php endif; ?>
        <li><a href="<?php echo e(route('upload-playlist')); ?>"><i class="fa fa-upload"></i> <span> Upload Playlist</span></a></li>
        <li>
            <a href="#" 
            href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
            document.getElementById('logout-form').submit();">
            <i class="fa fa-power-off"></i> <span>Logout</span>
         </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
              </form>
        </li>

      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside><?php /**PATH C:\Users\Algorithms\Documents\my jobs\php\virtual-dj\resources\views/layouts/aside.blade.php ENDPATH**/ ?>