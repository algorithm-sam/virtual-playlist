<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
          Import Playlist
        </h1>
    </section>

    <section class="content container-fluid">
        <section class="content">
                <div class="row">
                        <div class="col-xs-12">
                            <div class="box box-info">
                   <div class="box-header with-border">
                     <h3 class="box-title">Add Playlist Information From XML File</h3>
                   </div>
                   <!-- /.box-header -->
                   <!-- form start -->
                 <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(route('upload-playlist')); ?>">
                       <?php echo csrf_field(); ?>
                       <div class="box-body">
                         <div class="form-group">
                           <label for="name" class="col-sm-2 control-label">Select XML File</label>
                           <div class="col-sm-10">
                             <div>
                           <input type="file" name="file" class="form-control" id="name">
                           </div>
                           <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <div class="text-danger">
                               <?php echo e($message); ?>

                             </div>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                         </div>
                     
       
                     </div>
                     <!-- /.box-body -->
                     <div class="box-footer">
                       <button type="submit" class="btn btn-info">Upload</button>
                     </div>
                     <!-- /.box-footer -->
                   </form>
                 </div>
                        </div>
                    </div>
        </section>
    </section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Algorithms\Documents\my jobs\php\virtual-dj\resources\views/upload_playlist.blade.php ENDPATH**/ ?>