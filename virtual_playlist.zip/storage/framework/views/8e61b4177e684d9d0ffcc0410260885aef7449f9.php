<footer class="main-footer">
    <!-- To the right -->
    
    <!-- Default to the left -->
<strong>Copyright &copy; 2019 <a href="<?php echo e(url('/')); ?>">Information Management System</a>.</strong> All rights reserved.
  </footer><?php /**PATH C:\Users\Algorithms\Documents\my jobs\php\virtual-dj\resources\views/layouts/footer.blade.php ENDPATH**/ ?>