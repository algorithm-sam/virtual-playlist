<footer class="main-footer">
    <!-- To the right -->
    {{-- <div class="pull-right hidden-xs">
      Anything you want
    </div> --}}
    <!-- Default to the left -->
<strong>Copyright &copy; 2019 <a href="{{url('/')}}">Information Management System</a>.</strong> All rights reserved.
  </footer>